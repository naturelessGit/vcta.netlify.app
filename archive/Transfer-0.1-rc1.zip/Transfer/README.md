# Transfer — File sharing demo

Run locally:

1. npm install
2. PORT=3002 npm start

Open http://localhost:3000

have fun or smth idk lol
