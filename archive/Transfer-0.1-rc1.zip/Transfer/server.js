const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const cors = require('cors');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

const UPLOAD_DIR = path.join(__dirname, 'uploads');
if (!fs.existsSync(UPLOAD_DIR)) fs.mkdirSync(UPLOAD_DIR, { recursive: true });

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, UPLOAD_DIR),
  filename: (req, file, cb) => {
    const unique = Date.now() + '-' + Math.round(Math.random() * 1e9);
    cb(null, unique + path.extname(file.originalname));
  }
});

const upload = multer({ storage, limits: { fileSize: 500 * 1024 * 1024 } }); // 500MB limit

// Upload endpoint
app.post('/api/upload', upload.single('file'), (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'No file uploaded' });
  const fileMeta = {
    id: path.basename(req.file.filename),
    originalName: req.file.originalname,
    size: req.file.size,
    mime: req.file.mimetype,
    path: '/files/' + req.file.filename,
    createdAt: Date.now()
  };
  res.json(fileMeta);
});

// List files
app.get('/api/files', (req, res) => {
  fs.readdir(UPLOAD_DIR, (err, files) => {
    if (err) return res.status(500).json({ error: 'Failed to list files' });
    const items = files.map(f => {
      const stats = fs.statSync(path.join(UPLOAD_DIR, f));
      return {
        id: f,
        name: f,
        originalName: f,
        size: stats.size,
        mime: 'application/octet-stream',
        path: '/files/' + f,
        createdAt: stats.ctimeMs
      };
    });
    res.json(items.reverse());
  });
});

// Serve file download
app.get('/files/:name', (req, res) => {
  const filePath = path.join(UPLOAD_DIR, req.params.name);
  if (!fs.existsSync(filePath)) return res.status(404).send('Not found');
  res.download(filePath, (err) => {
    if (err) res.status(500).send('Failed to download');
  });
});

// Delete file
app.delete('/api/files/:name', (req, res) => {
  const filePath = path.join(UPLOAD_DIR, req.params.name);
  if (!fs.existsSync(filePath)) return res.status(404).json({ error: 'Not found' });
  fs.unlink(filePath, (err) => {
    if (err) return res.status(500).json({ error: 'Failed to delete' });
    res.json({ success: true });
  });
});

app.listen(PORT, () => {
  console.log(`Transfer app listening on http://localhost:${PORT}`);
});
