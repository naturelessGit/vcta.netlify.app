const api = {
  upload: '/api/upload',
  files: '/api/files'
};

const dropzone = document.getElementById('dropzone');
const fileInput = document.getElementById('fileInput');
const fileList = document.getElementById('fileList');
const progressWrap = document.getElementById('progressWrap');
const progressBar = document.getElementById('progressBar');
const progressInfo = document.getElementById('progressInfo');

function humanSize(n){
  if (n < 1024) return n+' B';
  if (n < 1024*1024) return (n/1024).toFixed(1)+' KB';
  if (n < 1024*1024*1024) return (n/1024/1024).toFixed(1)+' MB';
  return (n/1024/1024/1024).toFixed(2)+' GB';
}

async function listFiles(){
  const res = await fetch(api.files);
  const items = await res.json();
  fileList.innerHTML = items.map(item => renderFile(item)).join('');
  attachActions();
}

function renderFile(f){
  return `
  <li class="file-card" data-id="${f.id}">
    <div class="file-row">
      <div class="file-meta">
        <div class="thumb">📄</div>
        <div>
          <div style="font-weight:600">${escapeHtml(f.originalName || f.name)}</div>
          <div style="color:#9aa4b2;font-size:13px">${humanSize(f.size || 0)}</div>
        </div>
      </div>
      <div class="file-actions">
        <a class="btn" href="${f.path}" download>Download</a>
        <button class="btn" data-action="delete">Delete</button>
      </div>
    </div>
  </li>`;
}

function escapeHtml(str){
  return String(str).replace(/[&<>"]/g, s=>({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;"}[s]));
}

function attachActions(){
  document.querySelectorAll('[data-action="delete"]').forEach(btn => {
    btn.onclick = async (e) => {
      const li = e.target.closest('li');
      const id = li.dataset.id;
      if (!confirm('Delete this file?')) return;
      const res = await fetch('/api/files/' + id, { method: 'DELETE' });
      if (res.ok) { li.remove(); }
      else alert('Failed to delete');
    };
  });
}

async function uploadFile(file){
  const form = new FormData();
  form.append('file', file);
  progressWrap.hidden = false;
  progressBar.style.width = '0%';
  progressInfo.textContent = `Uploading ${file.name}`;

  const xhr = new XMLHttpRequest();
  xhr.open('POST', api.upload);
  xhr.upload.onprogress = (e) => {
    if (e.lengthComputable) {
      const pct = Math.round((e.loaded / e.total) * 100);
      progressBar.style.width = pct + '%';
      progressInfo.textContent = `${file.name} — ${pct}%`;
    }
  };
  xhr.onload = async () => {
    progressInfo.textContent = 'Processing...';
    setTimeout(() => { progressWrap.hidden = true; }, 600);
    await listFiles();
  };
  xhr.onerror = () => { alert('Upload failed'); progressWrap.hidden = true; };
  xhr.send(form);
}

dropzone.addEventListener('click', () => fileInput.click());
dropzone.addEventListener('dragover', (e) => { e.preventDefault(); dropzone.style.opacity = 0.95; });
dropzone.addEventListener('dragleave', () => { dropzone.style.opacity = 1; });
dropzone.addEventListener('drop', (e) => { e.preventDefault(); dropzone.style.opacity = 1; const f = e.dataTransfer.files[0]; if (f) uploadFile(f); });
fileInput.addEventListener('change', (e) => { const f = e.target.files[0]; if (f) uploadFile(f); });

// Initial load
listFiles().catch(err=>console.error(err));
